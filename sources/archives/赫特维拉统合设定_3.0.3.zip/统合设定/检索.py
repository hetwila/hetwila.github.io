#!/usr/bin/env python3
"""在本目录只读检索，返回定位与简短上下文。无需外部依赖。"""
from pathlib import Path
import argparse,re,sys
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('query',nargs='?',help='名称、关键词、H16-03、JR27等编号')
parser.add_argument('--year',type=int,help='本世界年份；纪元前写负数')
parser.add_argument('--limit',type=int,default=8,help='最多输出条目数，默认8')
parser.add_argument('--maintenance',action='store_true',help='同时搜索维护材料')
a=parser.parse_args()
if a.year is not None:
 y=a.year
 if not -2953<=y<=2026:parser.error('H年表覆盖前2953年至2026年；更早旅途请查03_文明与前史。')
 h=1 if y < -2900 else (y+3000)//100+1 if y<0 else y//100+31
 print(f'年份：{y}；历史段：H{h:02d}')
 for p in sorted((ROOT/'07_历代历史').glob(f'H{h:02d}*.md')):print(p.relative_to(ROOT))
 for i,(lo,hi) in enumerate([(-2953,-2301),(-2300,-1501),(-1500,-601),(-600,-1),(0,599),(600,1299),(1300,1799),(1800,1945),(1946,1989),(1990,2026)],1):
  if lo<=y<=hi:
   for p in (ROOT/'08_社会与技术史').glob(f'L{i:02d}_*.md'):print(p.relative_to(ROOT))
 print('进一步定位：00_检索/03_纪年与时代.md；00_检索/06_物品出现.md')
 if not a.query:sys.exit()
if not a.query:parser.error('请提供关键词或--year。')
q=a.query.strip().casefold();terms=q.split();hits=[]
for p in ROOT.rglob('*.md'):
 rel=p.relative_to(ROOT).as_posix()
 if rel.startswith('90_') and not a.maintenance:continue
 text=p.read_text(encoding='utf-8');anchor='';heading='';one=[]
 for no,line in enumerate(text.splitlines(),1):
  ids=re.findall(r'<a id="([^"]+)"></a>',line)
  if ids:anchor=ids[-1]
  if line.startswith('#'):heading=line.lstrip('# ').strip()
  bare=re.sub(r'<a id="[^"]+"></a>','',line)
  if all(t in bare.casefold() for t in terms):
   exact=any(x.casefold() in {q,'id-'+q} for x in ids)
   numbered=bool(re.match(r'^#{1,6}\s*'+re.escape(q)+r'(?:[｜：\s]|$)',line,re.I))
   score=100 if exact else 80 if numbered else 45 if q in p.stem.casefold() else 20
   if rel.startswith('00_'):score-=12
   one.append((score,rel,no,anchor,heading,re.sub(r'\s+',' ',bare).strip()))
 if one:hits.append(max(one,key=lambda x:(x[0],-x[2])))
hits.sort(key=lambda x:(-x[0],x[1],x[2]))
if not hits:
 print('未找到。可换用全名、编号或年份；未定内容见90_维护。');sys.exit(1)
for score,rel,no,anchor,heading,line in hits[:max(1,a.limit)]:
 print(rel+('#'+anchor if anchor else '')+f'  行{no}')
 print('  '+heading)
 print('  '+line[:220]+('…' if len(line)>220 else ''))
print(f'共命中{len(hits)}份文件；显示{min(len(hits),max(1,a.limit))}份。')
