#!/usr/bin/env python3
"""检查长度、链接、锚点落点、章节结构、稳定编号及可选发行哈希。"""
from pathlib import Path
import re,os,json,sys,hashlib,argparse
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--hashes',action='store_true');a=p.parse_args()
files={f.relative_to(ROOT).as_posix():f.read_text(encoding='utf-8') for f in ROOT.rglob('*') if f.is_file() and f.suffix in {'.md','.py','.json','.sha256'}}
errors=[];ids={};linkcount=0
for name,t in files.items():
 if len(t)>6500:errors.append(['超长',name,len(t)])
 if name.endswith('.md'):
  found=re.findall(r'<a id="([^"\n]+)"></a>',t);ids[name]=set(found)
  if len(found)!=len(set(found)):errors.append(['重复锚点',name])
  if '@@' in t:errors.append(['未解析链接',name])
  heads=list(re.finditer(r'(?m)^(#{1,6}) (.+)$',t))
  if sum(len(h[1])==1 for h in heads)!=1:errors.append(['页面标题数量',name])
  for i,h in enumerate(heads):
   if i and len(h[1])>len(heads[i-1][1])+1:errors.append(['标题跳级',name,h[2]])
   end=next((n.start() for n in heads[i+1:] if len(n[1])<=len(h[1])),len(t))
   body=re.sub(r'(?m)^#{1,6} .*$|<a id="[^"]+"></a>','',t[h.end():end]).strip()
   if not body:errors.append(['章节无内容',name,h[2]])
  for m in re.finditer(r'(?m)(?:^<a id="[^"]+"></a>\s*\n)+',t):
   group=re.findall(r'id="([^"]+)"',m[0]);tail=t[m.end():].lstrip()
   if not tail:errors.append(['页末孤立锚点',name,group])
   if len(group)>1:
    # 已有别名形态：总入口；H段；主题章与语义名。多个数值节号不作别名。
    valid=(group==['doc-core','core-01'] or
     len(group)==2 and re.fullmatch(r'event-h\d{2}',group[0]) and group[1]=='t02-chapter-'+group[0][-2:] or
     re.fullmatch(r't\d{2}-chapter-\d{2}',group[-1]) and all(not re.search(r'(?:chapter|section)-\d+$|-(?:\d{2})$',x) for x in group[:-1]))
    if not valid:errors.append(['相邻锚点需核对归属',name,group])
  for vid in (v for v in found if re.fullmatch(r'visual-(?:08|09|1[0-3])',v)):
   h=re.search(r'<a id="'+vid+r'"></a>\s*\n#{1,6} ([^\n]+)',t)
   if not h or '视觉' not in h[1] or '身体数据' not in h[1]:errors.append(['个人视觉标题不明确',name,vid])
for name,t in files.items():
 if not name.endswith('.md'):continue
 for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)',t):
  if re.match(r'\w+://|mailto:',target):continue
  file,sep,frag=target.partition('#');dest=os.path.normpath(os.path.join(os.path.dirname(name),file)) if file else name
  linkcount+=1
  if dest not in files:errors.append(['断链',name,target])
  elif frag and frag not in ids.get(dest,set()):errors.append(['无锚点',name,target])
flat=[i for v in ids.values() for i in v];counts={}
patterns={'百年事件':(r'h\d{2}-\d+',546),'百年段':(r'event-h\d{2}',51),'人物时代':(r'era-\d{2}',13),'技术分期':(r't13-life-s\d{2}',21),'外国':(r'country-f\d{2}',14),'战争':(r'war-w\d{2}',19),'邦国案例':(r'id-b\d{2}',12),'邦国节点':(r'id-bf\d{2}',40),'四邦政治节点':(r'id-(?:ilp|inp|chp|shp)\d{2}',64),'禁制节点':(r'id-jr\d{2}',48),'禁制人物':(r'id-k\d{2}',12),'议长届次':(r'chair-\d{2}',56),'政党':(r't06-party-pa\d{2}',9),'国际组织':(r't10-intl-i\d{2}',12),'文化流动分期':(r'id-c\d{2}',8)}
for label,(pat,want) in patterns.items():
 vals=[x for x in flat if re.fullmatch(pat,x)];counts[label]=len(vals)
 if len(vals)!=want or len(set(vals))!=want:errors.append(['编号覆盖',label,len(vals),want])
if a.hashes:
 for f in sorted(ROOT.glob('90_维护/文件校验_*.sha256')):
  for line in f.read_text().splitlines():
   digest,rel=line.split('  ',1);target=ROOT/rel
   if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=digest:errors.append(['内容校验失败',rel])
report={'结果':'通过' if not errors else '未通过','文本文件':len(files),'Markdown文档':len(ids),'链接':linkcount,'最长字符数':max(map(len,files.values())),'编号':counts,'错误':errors}
print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(bool(errors))
